<?php
require __DIR__ . '/fsphp.php';
fullStackPHPClassName("CLASS_TITLE");

/*
 * 
 */
fullStackPHPClassSession("", __LINE__);